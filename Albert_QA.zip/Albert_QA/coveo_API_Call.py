import json
import pandas as pd
import requests
def query_coveo(query):
    """
    Query Coveo search index
    Parameters
    ----------
    query : dict
    index_type : string
    Returns
    -------
    dict
    """
    # Coveo search API URL
    url = 'https://platform.cloud.coveo.com/rest/search/v2?organizationId=tataconsultancytrialgjmk41oz'
    # Header for Authentication
    headers = {"Content-Type": "text/plain",
               "Accept": "application/json",
               "Authorization": "Bearer xxf1dbb0ee-6333-4f32-8597-00806a0e7aeb"
               }
    # Query to be passed to Coveo
    Payload = {"lq": query, "cq": "@source==ExtremeNetworksData",
               "searchHub": "ENSearchHub"}
    # Recording response to the query
    response = requests.post(url, data=Payload, headers=headers, verify=False)
    data_files = response.json()
    # print(data_files['results'][0])
    coveo_results_lis = []
    # x= no of document search by coveo using query
    x = data_files['totalCountFiltered']
    if (x != 0):
        # Extracting required fields from response
        for i in range(0, 1):
            if i < 3:
                try:
                    if (data_files['results'][i]['title'] == ''):
                        continue
                    y = {"paragraph":data_files['results'][i]['raw']['paragraph'][0] + data_files['results'][i]['raw']['paragraph'][1]}
                    # print(y)
                    coveo_results_lis.append(y)
                except:
                    pass
    else:
        y = {"title": "No Result found", "score": 0}
        coveo_results_lis.append(y)
    print("COVEO - ", coveo_results_lis)
    return coveo_results_lis
# test
query = "what is the operating temperature of 3600 ?"
res = query_coveo(query)