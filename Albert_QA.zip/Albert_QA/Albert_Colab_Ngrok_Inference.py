

import timeit
start = timeit.default_timer()
import json
import time
import pandas as pd
import re
import config
import requests
import pandas as pd

Resultdf = pd.DataFrame(columns=['Answer_text', 'Prob_Score'])


def ngrok_api(questions, contexts,Resultdf):
    # Ngrok Url
    url = 'http://41c1b125e2b8.ngrok.io'
    # Header for Authentication
    # print(coveo_query)
    Payload ={"question": questions, "context": context }
    # Recording response to the query
    response = requests.post(url, json=Payload)
    data = response.json()
    Resultdf = Resultdf.append({'Answer_text': data['0'][0]['text'], 'Prob_Score': data['0'][0]['probability']}, ignore_index=True)
    print(data['0'][0]['text'],data['0'][0]['probability'])
    return Resultdf
    

questions=["what is the software warranty details of ERS 3600 ?"]

context= r"""
• Lifetime Hardware Warranty, providing Next Business Day shipment of replacement hardware.
• Lifetime Software Warranty, providing access to Updates and Upgrades.
• Lifetime Basic Technical Support.
• 90-Day Post-Purchase Advanced Technical Support.


"""

# Split Big Paragraph
splitted=context.split()
if len(splitted) > 480:
    print("inferencing with multiple paragraph")        
    x=0
    y=450
    contexts=[]
    while True:
        paragraph=' '.join(splitted[x:y])
        contexts.append(paragraph)
        remaining=len(splitted[y:])
        if (remaining<400):
            paragraph=' '.join(splitted[y:])
            contexts.append(paragraph)
            break
        x=y-50
        y=y+400

    for context in contexts:
        Resultdf = ngrok_api(questions, context,Resultdf)
    print(Resultdf.sort_values("Prob_Score", axis = 0, ascending = False))
else:
    print("inferencing with single paragraph")
    Resultdf = ngrok_api(questions, context, Resultdf)
    print(Resultdf)

stop = timeit.default_timer()
print('Total Run Time: ', stop - start)  




# code to run in google colab
'''
!git clone https://github.com/huggingface/transformers \
&& cd transformers \
&& git checkout a3085020ed0d81d4903c50967687192e3101e770 

!pip install ./transformers
!pip install tensorboardX
!pip install flask_restful
!pip install pyngrok

!ngrok authtoken 1hYCoPfGid6rzZcXE2JDyJpswbL_7Ktyi7mrfbhr3jcdzvvMa (signup in ngrok to get authtoken)

import json 
from flask import Flask,request,jsonify
from flask_restful import Resource, Api
import os
import torch
import time
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler

from transformers import (
    AlbertConfig,
    AlbertForQuestionAnswering,
    AlbertTokenizer,
    squad_convert_examples_to_features
)

from transformers.data.processors.squad import SquadResult, SquadV2Processor, SquadExample

from transformers.data.metrics.squad_metrics import compute_predictions_logits

# READER NOTE: Set this flag to use own model, or use pretrained model in the Hugging Face repository
use_own_model = False



if use_own_model:
  model_name_or_path = "/content/model_output"
else:
  model_name_or_path = "ktrapeznikov/albert-xlarge-v2-squad-v2"

output_dir = ""

app=Flask(__name__)
# Config
n_best_size = 1
max_answer_length = 30
do_lower_case = True
null_score_diff_threshold = 0.0

def to_list(tensor):
    return tensor.detach().cpu().tolist()

# Setup model
config_class, model_class, tokenizer_class = (
    AlbertConfig, AlbertForQuestionAnswering, AlbertTokenizer)
config = config_class.from_pretrained(model_name_or_path)
tokenizer = tokenizer_class.from_pretrained(
    model_name_or_path, do_lower_case=True)
model = model_class.from_pretrained(model_name_or_path, config=config)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model.to(device)

processor = SquadV2Processor()

@app.route('/', methods=['POST'])

def run_prediction():
    """Setup function to compute predictions"""
    query=request.get_json()
    question_texts=query['question']
    context_text=query['context']
    examples = []

    for i, question_text in enumerate(question_texts):
        example = SquadExample(
            qas_id=str(i),
            question_text=question_text,
            context_text=context_text,
            answer_text=None,
            start_position_character=None,
            title="Predict",
            is_impossible=False,
            answers=None,
        )

        examples.append(example)

    features, dataset = squad_convert_examples_to_features(
        examples=examples,
        tokenizer=tokenizer,
        max_seq_length=384,
        doc_stride=128,
        max_query_length=64,
        is_training=False,
        return_dataset="pt",
        threads=1,
    )

    eval_sampler = SequentialSampler(dataset)
    eval_dataloader = DataLoader(dataset, sampler=eval_sampler, batch_size=10)

    all_results = []

    for batch in eval_dataloader:
        model.eval()
        batch = tuple(t.to(device) for t in batch)

        with torch.no_grad():
            inputs = {
                "input_ids": batch[0],
                "attention_mask": batch[1],
                "token_type_ids": batch[2],
            }

            example_indices = batch[3]

            outputs = model(**inputs)

            for i, example_index in enumerate(example_indices):
                eval_feature = features[example_index.item()]
                unique_id = int(eval_feature.unique_id)

                output = [to_list(output[i]) for output in outputs]

                start_logits, end_logits = output
                result = SquadResult(unique_id, start_logits, end_logits)
                all_results.append(result)

    output_prediction_file = "predictions.json"
    output_nbest_file = "nbest_predictions.json"
    output_null_log_odds_file = "null_predictions.json"

    predictions = compute_predictions_logits(
        examples,
        features,
        all_results,
        n_best_size,
        max_answer_length,
        do_lower_case,
        output_prediction_file,
        output_nbest_file,
        output_null_log_odds_file,
        False,  # verbose_logging
        True,  # version_2_with_negative
        null_score_diff_threshold,
        tokenizer,
    )
    print(predictions)
    f = open('nbest_predictions.json',) 
    # returns JSON object as 
    # a dictionary 
    data = json.load(f) 
    return (data)
if __name__== '__main__':
    app.run(host='localhost',port='5004',debug=True,use_reloader=False)


'''
