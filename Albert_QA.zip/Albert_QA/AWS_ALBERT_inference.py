import timeit
start = timeit.default_timer()
import json
import time
import pandas as pd
import re
import config
import requests
import pandas as pd


questions=  ["how many buffers does SLX 9740 have"]
context=  "The border router is the interconnection point between internal networks and the internet. With more traffic moving across these routers, there is added demand for capacity, the ability to absorb speed mismatches and handle microbursts without compromising performance. The SLX 9740 has up to 16GB of deep packet buffers."
url = 'https://pf0dttp4df.execute-api.us-east-1.amazonaws.com/inference/qa-bert'
# Header for Authentication
# print(coveo_query)
Payload ={"question": questions, "context": context }
# Recording response to the query
response = requests.post(url, json=Payload)
data = response.json()

# Resultdf = Resultdf.append({'Answer_text': data['0'][0]['text'], 'Prob_Score': data['0'][0]['probability']}, ignore_index=True)
print(data['0'][0]['text'],data['0'][0]['probability'])

stop = timeit.default_timer()
print('Total Run Time: ', stop - start)  
