import timeit
start = timeit.default_timer()
import json
import time
import pandas as pd
import re
import config
import requests
import pandas as pd

url = 'http://0c547d89259f.ngrok.io'
# Header for Authentication
# print(coveo_query)
Payload ={"question": 'what is your name', "context": 'my name is sanjeev' }
# Recording response to the query
response = requests.post(url, json=Payload)
data = response.json()
print(data)