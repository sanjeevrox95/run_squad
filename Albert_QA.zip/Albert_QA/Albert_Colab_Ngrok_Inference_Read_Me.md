Read ME file for Albert_Colab_Ngrok_Inference and domain fine tuning


* We have used "https://colab.research.google.com/github/spark-ming/albert-qa-demo/blob/master/Question_Answering_with_ALBERT.ipynb#scrollTo=QOAoUwBFMQCg"
  colab notebook for Albert Q&A closed domain fine tuning and inferencing
* for Albert Q&A finetuning we need to create our custom training examples in SQUAD training data format and append this data to squad Training data.
* we can play with hyperparameter to improve the model accuracy


Ngrok : It helps us to create public endpoint for local endpoint

steps to use colab with ngrok
1. Run the ML model code in google colab notebook and create Flask or any other endpoint for inferencing in colab (we will use ngrok to make local endpoint to public)
2. !pip install pyngrok
3. !ngrok authtoken 1hYCoPfGid6rzZcXE2JDyJpswbL_7Ktyi7mrfbhr3jcdzvvMa (signup in ngrok to get authtoken)
4. run below code in colab notebook to generate public URL for local hosted url
   from pyngrok import ngrok
   public_url = ngrok.connect(port='5004')
   print(public_url ) : http://038d962e9f1b.ngrok.io (public URL looks similar to this)

Note : make sure you are using @app.route('/',methods=['POST'])

Albert google colab notebook
https://colab.research.google.com/github/spark-ming/albert-qa-demo/blob/master/Question_Answering_with_ALBERT.ipynb#scrollTo=-JCNRkQwUD56

**********************************************************************
summary:
1. In Albert/bert we can pass maximum of 512 no of tokens, if we have long context we need to split the context (the same code is executed in "Coveo_ngrok_connection.ipynb")
2. Albert/bert is suitalbe for short answer
3. Albert/bert will not perform well with table as context/paragraph
4. for our extreme network use case we found already pretrained model is performing better as closed domain (custom) fine tuning.
  but we can play with hyperparamter like learning rate and no of ephocs to improve closed domain fine tuning accuracy 
5. while custom fine tuning/ closed domain training please make sure increse the number of epochs(~10) and max_seq_length (512) if you are dealing with long context.
   please make sure that to use this Alber Q&A model for short answer only (~ 10 tokens). For long annwer it may not work properly 

5. for result comparison between custom finetuned Albert model and pre trainded mode refer "Albert_result_comparison.xlsx" in data folder
***********************************************************************
