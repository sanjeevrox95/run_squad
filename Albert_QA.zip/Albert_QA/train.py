#!/usr/bin/env python

# Some boilerplate code. Sagemaker expects to have a model definition in /opt/ml/model
# We copy the model to that location, however we don't use it in inference
# we are not using this train file 
import os
import sys
import traceback
import shutil
import subprocess
import argparse

# These are the paths to where SageMaker mounts interesting things in your container.
prefix = '/opt/ml/'

input_path = prefix + 'input/data'
output_path = os.path.join(prefix, 'output')
model_path = os.path.join(prefix, 'model')
param_path = os.path.join(prefix, 'input/config/hyperparameters.json')  # make it a dict with kwargs



def train(args):
    try:
        training_dir =args.training
        testing_dir =args.testing
        training_file =os.path.join(training_dir,'train_data_30.json')
        testing_file = os.path.join(testing_dir,'dev_v2.json')
        subprocess.run('python run_squad.py \
        --model_type albert \
        --model_name_or_path ktrapeznikov/albert-xlarge-v2-squad-v2 \
        --do_train \
        --do_eval \
        --do_lower_case \
        --train_file ' + training_file + ' \
        --predict_file ' + testing_file + ' \
        --per_gpu_train_batch_size 3 \
        --learning_rate 3e-5 \
        --num_train_epochs 1.0 \
        --max_seq_length 384 \
        --doc_stride 128 \
        --output_dir ../model \
        --save_steps 1000 \
        --threads 4 \
        --version_2_with_negative', shell=True)
        print('Training complete!!')
    except Exception as e:
        # Write out an error file. This will be returned as the failureReason in the
        # DescribeTrainingJob result.
        trc = traceback.format_exc()
        with open(os.path.join(output_path, 'failure'), 'w') as s:
            s.write('Exception during training: ' + str(e) + '\n' + trc)
        # Printing this causes the exception to be in the training job logs, as well.
        print('Exception during training: ' + str(e) + '\n' + trc)
        # A non-zero exit code causes the training job to be marked as Failed.
        sys.exit(255)


if __name__ == '__main__':
      parser = argparse.ArgumentParser()
  # reads input channels training and testing from the environment variables
      parser.add_argument("--training", type=str, default=os.environ['SM_CHANNEL_TRAINING'])
      parser.add_argument("--testing", type=str, default=os.environ['SM_CHANNEL_TESTING'])
      parser.add_argument("--model-dir",type=str,default=os.environ['SM_MODEL_DIR'])
      args = parser.parse_args()
      train(args)

    # A zero exit code causes the job to be marked a Succeeded.


      sys.exit(0)

